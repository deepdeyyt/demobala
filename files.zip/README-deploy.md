```markdown
# Deploy instructions — GitHub Pages and Netlify

This repository contains a static site for BALAJI DIGICOM. Below are ready-to-use deployment configurations for GitHub Pages and Netlify.

## GitHub Pages (recommended via GitHub Actions)
- File added: `.github/workflows/deploy-pages.yml`
- Behavior: On every push to `main`, the workflow uploads the repository contents to GitHub Pages.
- How it publishes:
  - By default the Pages site will be published and managed by the workflow. After the first successful run, go to the repository Settings → Pages to verify the site URL (usually https://<username>.github.io/<repo>/).
  - If you prefer to serve from `main` branch / `docs/` folder instead, you can enable that in Settings → Pages and remove the workflow.

Notes:
- If your site requires a build step (React/Vite/Hugo/etc.), uncomment or add a Build step in the workflow and upload the build output path (e.g. `dist/` or `public/`) instead of `./`.
- To use a custom domain, add a `CNAME` file at the repo root with your domain and configure DNS accordingly.

## Netlify
- File added: `netlify.toml`
- How to use:
  1. Go to https://app.netlify.com/ and "New site from Git".
  2. Connect your GitHub repo and choose the branch (e.g., `main`).
  3. Set build command to blank (or to your project build command if applicable) and publish directory to `/` (or to `dist`/`build` if you have a build step).
  4. Deploy — Netlify will publish the site and give you a URL. You can link a custom domain in Netlify UI.

Netlify Forms:
- If you want the contact form to be handled by Netlify Forms, add `data-netlify="true"` and a hidden `form-name` input to your `<form>`. See the snippet below.

## Netlify Forms snippet (drop this into your existing contact form)
```html
<form name="contact" method="POST" data-netlify="true" netlify-honeypot="bot-field">
  <input type="hidden" name="form-name" value="contact">
  <p style="display:none">
    <label>Don’t fill this out if you're human: <input name="bot-field"></label>
  </p>

  <!-- Your existing inputs: -->
  <label>
    <span>Name</span>
    <input type="text" name="name" required>
  </label>
  <label>
    <span>Phone</span>
    <input type="tel" name="phone" required>
  </label>
  <label>
    <span>Email</span>
    <input type="email" name="email">
  </label>
  <label>
    <span>Message</span>
    <textarea name="message" required></textarea>
  </label>

  <button type="submit">Send Message</button>
</form>
```

## Additional tips
- HTTPS: Both GitHub Pages and Netlify provide HTTPS automatically for their provided domains. For custom domains follow each provider’s domain/DNS instructions.
- If you want CI-based deployments for a built site (React/Vue/Hugo), update the workflow and netlify.toml to run the build command and publish from the build output directory.
- If you'd like, I can:
  - Update your index.html to include the Netlify form attributes automatically.
  - Add a small GitHub Actions build step if you plan to use a static site generator.
  - Create a CNAME or DNS instructions for a custom domain.
```