# BALAJI DIGICOM — Basic Website

This is a simple static website starter for BALAJI DIGICOM. It includes:

- index.html — main page with hero, services, about, contact.
- css/styles.css — responsive styles.
- js/main.js — small client-side script for basic form validation and UI niceties.

Contact details included:
- Address: Surya Road, Near SBI Bazar Branch, Agartala, West Tripura, Agartala, India, Tripura
- Phone: 87944 44405

How to use:
1. Open `index.html` in a browser for a local preview.
2. To publish:
   - Push to a GitHub repository and enable GitHub Pages, or
   - Deploy to Netlify/Vercel/any static host.

To make the contact form functional:
- Connect the form to a backend endpoint (e.g., a simple Node/Express endpoint), or
- Use a form service like Formspree, Getform, or Netlify Forms.

Customize:
- Replace placeholder email `info@balajidigicom.example` with a real email.
- Update styles in `css/styles.css`.
- Add your logo and images in an `assets/` folder and update `index.html`.

If you'd like, I can:
- Add a downloadable sitemap or privacy page.
- Wire up the contact form to a serverless function or Formspree.
- Create multiple pages (Plans, Support, Terms).
- Generate optimized images and a favicon package.
